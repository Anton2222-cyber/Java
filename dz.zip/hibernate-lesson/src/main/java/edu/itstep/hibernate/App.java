package edu.itstep.hibernate;

public class App {
    public static void main(String[] args) {
        ExamStudentApp examStudentApp = new ExamStudentApp();
        examStudentApp.startWork();
    }
}
