package edu.itstep.hibernate;

public class App {
    public static void main(String[] args) {

        CountryPresidentApp countryPresidentApp = new CountryPresidentApp();
        countryPresidentApp.startWork();
    }
}
