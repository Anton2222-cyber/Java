package game;

public interface Pusher {
    void attack(Character oponent);
}
