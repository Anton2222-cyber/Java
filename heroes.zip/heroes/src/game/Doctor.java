package game;

public interface Doctor {
   void toHealth(Character partner);
}
