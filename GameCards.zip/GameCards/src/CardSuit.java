public enum CardSuit {
    CLUBS,      // Трефи(хресто)
    DIAMONDS,   // Бубни
    HEARTS,     // Чирви
    SPADES      // Піки
}
