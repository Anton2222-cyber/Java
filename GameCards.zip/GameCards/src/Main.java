import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();
//        Deck deck = new Deck(DeckSize.SIZE52); // Створення колоди розміром 52 карти
//        deck.shuffleDeck();
//        List<Card> cards = deck.getCards();
//
//        for (Card card : cards) {
//            System.out.println(card.getCardValue() + " of " + card.getCardSuit());
//        }
//        System.out.println("--------");
//        Card card3 = deck.drawLastCard();
//        System.out.println(card3.getCardValue() + " " + card3.getCardSuit());
//        System.out.println("--------");
//        cards = deck.getCards();
//
//
//        for (Card card : cards) {
//            System.out.println(card.getCardValue() + " of " + card.getCardSuit());
//        }
//        System.out.println("--------");
//        System.out.println("--------");
//        System.out.println("--------");
//        deck.addCard(card3);
//        cards = deck.getCards();
//        for (Card card : cards) {
//            System.out.println(card.getCardValue() + " of " + card.getCardSuit());
//        }
    }

}
