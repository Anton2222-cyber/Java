public enum DeckSize {
    SIZE36,
    SIZE52
}
