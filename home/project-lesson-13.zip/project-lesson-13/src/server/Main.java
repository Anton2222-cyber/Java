package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(45678);
            System.out.println("server created");

            Socket socket = serverSocket.accept();
            System.out.println("client connected");
            Scanner scanner = new Scanner(socket.getInputStream());
            String message = scanner.nextLine();
            System.out.println(message);

            socket = serverSocket.accept();
            System.out.println("client connected");
            scanner = new Scanner(socket.getInputStream());
            message = scanner.nextLine();
            System.out.println(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
