package client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private final String IP;
    private final int PORT;

    public Client(String IP, int PORT) {
        this.IP = IP;
        this.PORT = PORT;
    }

    public void start() {
        try {
            Socket socket = new Socket(IP, PORT);
            new Thread(new ServerListener(socket)).start();
            Scanner scannerConsole = new Scanner(System.in);
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());

            while (true) {
                String message = scannerConsole.nextLine();
                printWriter.println(message);
                printWriter.flush();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
