package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClientListener implements Runnable {
    private Socket socket;
    private Scanner scanner;
    private PrintWriter printWriter;

    public ClientListener(Socket socket) {
        this.socket = socket;
        try {
            scanner = new Scanner(socket.getInputStream());
            printWriter = new PrintWriter(socket.getOutputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void run() {
        while (scanner.hasNextLine()) {
            String messageFromClient = scanner.nextLine();
            System.out.println(messageFromClient);
            Server.sendMessageToAll(messageFromClient);
        }
    }

    public void sendMessage(String message) {
        printWriter.println(message);
        printWriter.flush();
    }
}
