package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private static List<ClientListener> clientListeners = new ArrayList<>();
    public void start(){
        try {
            ServerSocket serverSocket = new ServerSocket(44444);
            System.out.println("created");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("client connected");
                ClientListener clientListener = new ClientListener(socket);
                clientListeners.add(clientListener);
                new Thread(clientListener).start();
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void sendMessageToAll(String message) {
        clientListeners.forEach(e -> e.sendMessage(message));
    }
}
