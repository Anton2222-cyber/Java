package edu.itstep.mvc.model;

import javax.validation.constraints.*;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class User {
    @Size(min = 2, max = 20, message = "First name is not correct...")
    @Pattern(regexp = "[A-Za-zА-Яа-я]+", message = "Only letters are allowed")
    @NotBlank(message = "This field must not be empty")
    private String firstName;

    @Size(min = 2, max = 20, message = "Last name is not correct...")
    @Pattern(regexp = "[A-Za-zА-Яа-я]+", message = "Only letters are allowed")
    @NotBlank(message = "This field must not be empty")
    private String lastName;

    @NotNull(message = "This field must not be empty")
    @Digits(integer = 10, fraction = 0, message = "Please enter a valid age")
    @Min(value = 18, message = "Age must be 18 or older")
    private Integer age;

    @NotBlank(message = "This field must not be empty")
    private String gender;

    private Map<String, String> genders = new TreeMap<>();

    {
        genders.put("male", "male");
        genders.put("female", "female");
        genders.put("other", "other");
    }

    public Map<String, String> getGenders() {
        return genders;
    }

    public void setGenders(Map<String, String> genders) {
        this.genders = genders;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public User(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public User() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
